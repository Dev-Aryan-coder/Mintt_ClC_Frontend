import React, { useState, useEffect, useRef } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import { useModal } from '../../context/ModalContext';
import MobileMenu from './MobileMenu';

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isServicesDropdownOpen, setIsServicesDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  const location = useLocation();
  const { openBooking } = useModal();

  const isServicesActive =
    location.pathname.startsWith('/services') ||
    location.pathname.startsWith('/therapies') ||
    location.pathname.startsWith('/areas-of-support');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.pageYOffset > 8);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close dropdown on outside click or navigation
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsServicesDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    setIsServicesDropdownOpen(false);
  }, [location.pathname]);

  return (
    <>
      <header className={`site-header sticky-top ${isScrolled ? 'is-scrolled' : ''}`}>
        <div className="container site-header__inner">
          <Link to="/" className="brand" aria-label="Child Learning Centre, home">
            <img src="/assets/logo/clc-logo.png" alt="Child Learning Centre logo" height="44" />
            <span className="brand__text">
              <span className="brand__name">
                CLC<span>.</span>
              </span>
              <span className="brand__tag d-none d-sm-block">Pediatric Development</span>
            </span>
          </Link>

          <nav className="site-nav d-none d-xl-flex align-items-center" aria-label="Main">
            <NavLink
              to="/"
              className={({ isActive }) => (isActive ? 'is-active' : '')}
              end
            >
              Home
            </NavLink>
            <NavLink
              to="/about"
              className={({ isActive }) => (isActive ? 'is-active' : '')}
            >
              About
            </NavLink>

            {/* Services Dropdown (Option 3: Butterfly Learnings pediatric health style) */}
            <div
              className={`nav-item dropdown custom-nav-dropdown ${isServicesDropdownOpen ? 'show' : ''}`}
              ref={dropdownRef}
              onMouseEnter={() => setIsServicesDropdownOpen(true)}
              onMouseLeave={() => setIsServicesDropdownOpen(false)}
            >
              <button
                type="button"
                className={`nav-link dropdown-toggle nav-dropdown-btn ${isServicesActive ? 'is-active' : ''}`}
                onClick={() => setIsServicesDropdownOpen((prev) => !prev)}
                aria-expanded={isServicesDropdownOpen}
                aria-haspopup="true"
              >
                Services
                <i className="bi bi-chevron-down ms-1 small"></i>
              </button>

              <div
                className={`dropdown-menu custom-dropdown-menu shadow-lg p-2 ${
                  isServicesDropdownOpen ? 'show' : ''
                }`}
              >
                <Link
                  to="/services/therapies"
                  className={`dropdown-item custom-dropdown-item d-flex align-items-center gap-3 p-2 rounded-2 ${
                    location.pathname === '/services/therapies' || location.pathname === '/therapies'
                      ? 'active-subnav'
                      : ''
                  }`}
                >
                  <div className="dropdown-icon-box bg-danger-subtle text-danger rounded-2 d-flex align-items-center justify-content-center">
                    <i className="bi bi-heart-pulse-fill"></i>
                  </div>
                  <div>
                    <span className="fw-bold d-block text-dark small">Therapy Programs</span>
                    <span className="text-muted text-xs d-block">
                      Occupational, Speech, Sensory &amp; ADHD
                    </span>
                  </div>
                </Link>

                <div className="dropdown-divider my-1"></div>

                <Link
                  to="/services/areas-of-support"
                  className={`dropdown-item custom-dropdown-item d-flex align-items-center gap-3 p-2 rounded-2 ${
                    location.pathname === '/services/areas-of-support' || location.pathname === '/areas-of-support'
                      ? 'active-subnav'
                      : ''
                  }`}
                >
                  <div className="dropdown-icon-box bg-primary-subtle text-primary rounded-2 d-flex align-items-center justify-content-center">
                    <i className="bi bi-grid-fill"></i>
                  </div>
                  <div>
                    <span className="fw-bold d-block text-dark small">Areas of Support</span>
                    <span className="text-muted text-xs d-block">
                      Speech Delays, Sensory Meltdowns, Focus &amp; Motor
                    </span>
                  </div>
                </Link>
              </div>
            </div>

            <NavLink
              to="/how-it-works"
              className={({ isActive }) => (isActive ? 'is-active' : '')}
            >
              How It Works
            </NavLink>
            <NavLink
              to="/centres"
              className={({ isActive }) => (isActive ? 'is-active' : '')}
            >
              Centres
            </NavLink>
            <NavLink
              to="/reviews"
              className={({ isActive }) => (isActive ? 'is-active' : '')}
            >
              Reviews
            </NavLink>
            <NavLink
              to="/contact"
              className={({ isActive }) => (isActive ? 'is-active' : '')}
            >
              Contact
            </NavLink>
          </nav>

          <div className="header-actions">
            <a
              href="tel:+919004460650"
              className="btn btn-clc-outline d-none d-xxl-inline-flex"
            >
              <i className="bi bi-telephone"></i>Call us
            </a>
            <button
              type="button"
              className="btn btn-clc d-none d-sm-inline-flex"
              onClick={() => openBooking()}
            >
              Book a consultation
            </button>
            <button
              type="button"
              className="menu-toggle d-xl-none"
              onClick={() => setIsMobileMenuOpen(true)}
              aria-label="Open menu"
            >
              <i className="bi bi-list" aria-hidden="true"></i>
            </button>
          </div>
        </div>
      </header>

      <MobileMenu
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
      />
    </>
  );
}
